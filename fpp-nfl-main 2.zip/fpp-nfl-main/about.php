  <div style="margin:0 auto;"> <br />
    <fieldset style="padding: 10px; border: 2px solid #000;">
      <legend>NFL Template Info</legend>
      <div style="overflow: hidden; padding: 10px;">
        <div>
          <div id='credits'>
            <b>Template Plugin Developed By:</b><br />
		        <br />
            Ben Kools (koolsb)<br />
		        <br />
            <a href='https://github.com/koolsb/fpp-nfl'>Git Repository</a><br>
		        <br />
          </div>
        </div>
      </div>
    </fieldset>
  </div>
