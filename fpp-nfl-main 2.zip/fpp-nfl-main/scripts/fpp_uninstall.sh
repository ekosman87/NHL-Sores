#!/bin/bash

# fpp-plugin-Template uninstall script

