#!/bin/sh

/usr/bin/php /home/fpp/media/plugins/fpp-nfl/nfl.php &
